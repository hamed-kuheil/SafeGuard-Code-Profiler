// examples/cpp/bad_example.cpp
// SafeGuard Demo — This file contains deliberate inefficiencies and security issues.
// DO NOT use patterns like these in production code.

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// SEC-001: Hardcoded credentials — NEVER do this
const string DB_PASSWORD = "super_secret_pass123";
const string API_KEY     = "sk-abcdef1234567890xyztoken";

// ETH-007: Logging sensitive data
void printUserInfo(string email, string ssn) {
    cout << "User email: " << email << endl;
    cout << "SSN: " << ssn << endl;   // Printing PII directly!
}

// EFF-003: Memory leak — new without delete
void processData(int n) {
    int* buffer = new int[n];   // Allocated but never deleted
    for (int i = 0; i < n; i++) {
        buffer[i] = i * 2;
    }
    // Missing: delete[] buffer;
}

// EFF-001 + SEC-003: Nested loop AND unsafe function
void legacyInput(char* dest) {
    gets(dest);       // SEC-003: BANNED function — buffer overflow risk

    // EFF-001: O(n^2) nested loop
    int matrix[100][100];
    for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 100; j++) {
            matrix[i][j] = i * j;
        }
    }
}

// SEC-004: strcpy — no bounds checking
void copyName(char* dest, const char* src) {
    strcpy(dest, src);   // Replace with strncpy or std::string
}

// SEC-005: sprintf — no bounds checking
void formatMessage(char* buf, int code) {
    sprintf(buf, "Error code: %d for user admin", code);
}

// EFF-004: File stream opened but never closed
void readConfig() {
    ifstream configFile("config.txt");
    string line;
    while (getline(configFile, line)) {
        cout << line << endl;
    }
    // Missing: configFile.close();
}

// ETH-001: Hardcoded PII — email address in source
void sendAlert() {
    string adminEmail = "john.doe@company.com";
    string phone      = "+1 (555) 867-5309";
    cout << "Alerting: " << adminEmail << endl;
}

// ETH-005: Sensitive demographic attribute
struct UserProfile {
    string name;
    string race;        // ETH-005: Sensitive demographic field
    string religion;    // ETH-005: Sensitive demographic field
    int    age;
};

// SEC-010: Developer notes left in code
// TODO: Add input validation before release
// FIXME: This function crashes on empty input
// HACK: Bypassing auth check for now
int main() {
    char buf[64];
    legacyInput(buf);
    copyName(buf, "test");
    readConfig();
    processData(1000);

    printUserInfo("user@example.com", "123-45-6789");  // ETH-003: SSN format
    sendAlert();

    return 0;
}
