// examples/cpp/good_example.cpp
// SafeGuard Demo — Clean, efficient, and ethically sound C++ code.

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <memory>
#include <cstdlib>
#include <stdexcept>
using namespace std;

// ✓ Credentials loaded from environment variables — never hardcoded
string getDbPassword() {
    const char* pw = std::getenv("DB_PASSWORD");
    if (!pw) throw std::runtime_error("DB_PASSWORD env var not set");
    return string(pw);
}

// ✓ Smart pointer — no manual new/delete, no memory leaks
void processData(int n) {
    auto buffer = std::make_unique<int[]>(n);
    for (int i = 0; i < n; i++) {
        buffer[i] = i * 2;
    }
    // Automatically freed when buffer goes out of scope
}

// ✓ Safe string input with bounds — no gets(), no strcpy()
void safeInput(string& dest) {
    std::getline(std::cin, dest);
}

// ✓ snprintf with explicit buffer size
void formatMessage(char* buf, size_t bufSize, int code) {
    snprintf(buf, bufSize, "Error code: %d", code);
}

// ✓ RAII file handling — no explicit close() needed
void readConfig(const string& path) {
    std::ifstream configFile(path);
    if (!configFile.is_open()) {
        cerr << "Config file not found: " << path << endl;
        return;
    }
    string line;
    while (getline(configFile, line)) {
        cout << line << "\n";
    }
    // File automatically closed when configFile leaves scope
}

// ✓ O(n) algorithm using sorting + two-pointer instead of O(n^2) search
vector<pair<int,int>> findPairsWithSum(vector<int>& arr, int target) {
    sort(arr.begin(), arr.end());
    vector<pair<int,int>> result;
    int left = 0, right = (int)arr.size() - 1;
    while (left < right) {
        int sum = arr[left] + arr[right];
        if      (sum == target) { result.push_back({arr[left++], arr[right--]}); }
        else if (sum <  target) { left++;  }
        else                    { right--; }
    }
    return result;
}

// ✓ Anonymized user struct — no sensitive demographics stored
struct UserProfile {
    string userId;      // Anonymized ID, not real name
    int    ageGroup;    // Age bracket, not exact age (e.g., 25-34)
    // No race, religion, or biometric fields
};

// ✓ No PII in logs — log IDs, not personal data
void logUserAction(const string& userId, const string& action) {
    cout << "[LOG] User:" << userId << " Action:" << action << "\n";
    // Never log passwords, tokens, emails, or SSNs
}

int main() {
    try {
        string input;
        safeInput(input);

        char msgBuf[256];
        formatMessage(msgBuf, sizeof(msgBuf), 42);

        readConfig("config.txt");

        vector<int> data = {1, 5, 3, 2, 8, 4, 7};
        auto pairs = findPairsWithSum(data, 9);

        processData(1000);
        logUserAction("user-7f3a2b", "login");
    } catch (const exception& e) {
        cerr << "Error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
