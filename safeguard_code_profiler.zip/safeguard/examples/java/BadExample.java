// examples/java/BadExample.java
// SafeGuard Demo — Deliberately flawed Java code for analysis.

import java.sql.*;
import java.io.*;
import java.lang.reflect.*;

public class BadExample {

    // SEC-001: Hardcoded credentials
    private static final String PASSWORD = "admin_pass_2024";
    private static final String API_KEY  = "live_key_abcdef1234567890";

    // ETH-001: Hardcoded PII
    private static final String ADMIN_EMAIL = "bob.smith@company.org";

    // EFF-001 + EFF-007: Nested loop + string concat in loop
    public static String buildMatrix(int n) {
        String result = "";
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                result += i + "," + j + " ";  // EFF-007: String += in loop = O(n^2) memory
            }
        }
        return result;
    }

    // SEC-006: SQL injection
    public static ResultSet getUser(Connection conn, String username) throws SQLException {
        Statement stmt = conn.createStatement();
        String query = "SELECT * FROM users WHERE name = '" + username + "'";  // Injection!
        return stmt.executeQuery(query);
    }

    // ETH-005: Sensitive demographic fields in model
    static class UserRecord {
        String  name;
        String  email;
        String  race;        // ETH-005
        String  religion;    // ETH-005
        boolean isMinor;     // ETH-010: minor targeting
    }

    // ETH-007: Logging sensitive info
    public static void loginUser(String user, String password) {
        System.out.println("Login attempt: user=" + user + " password=" + password);
    }

    // SEC-011: Java Reflection — bypasses access control
    public static Object accessPrivateField(Object obj, String fieldName) throws Exception {
        Class<?> clazz = Class.forName(obj.getClass().getName());
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);      // SEC-011
        return field.get(obj);
    }

    // EFF-008: Unconditional while(true)
    public static void pollServer() {
        while (true) {
            // No break condition visible — potential infinite loop
            System.out.println("Polling...");
        }
    }

    // SEC-010: Developer notes
    // TODO: Remove hardcoded credentials before release
    // FIXME: SQL injection vulnerability in getUser()
    // HACK: Auth check disabled for development

    public static void main(String[] args) throws Exception {
        System.out.println(buildMatrix(10));
        loginUser("admin", PASSWORD);   // ETH-007

        // ETH-003: SSN-like string hardcoded
        String testSSN = "987-65-4321";
        System.out.println("Test SSN: " + testSSN);
    }
}
