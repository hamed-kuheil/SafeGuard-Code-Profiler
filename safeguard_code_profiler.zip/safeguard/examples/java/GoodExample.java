// examples/java/GoodExample.java
// SafeGuard Demo — Clean, secure, and ethically sound Java code.

import java.sql.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.logging.*;

public class GoodExample {

    private static final Logger LOGGER = Logger.getLogger(GoodExample.class.getName());

    // ✓ Credentials from environment variables
    private static final String API_KEY = System.getenv("API_KEY");

    static {
        if (API_KEY == null || API_KEY.isEmpty()) {
            throw new ExceptionInInitializerError("API_KEY environment variable is required");
        }
    }

    // ✓ O(n log n) matrix build with StringBuilder
    public static String buildMatrix(int n) {
        StringBuilder sb = new StringBuilder();  // O(n) amortized vs String +='s O(n^2)
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                sb.append(i).append(',').append(j).append(' ');
            }
        }
        return sb.toString();
    }

    // ✓ Parameterized query — safe from SQL injection
    public static ResultSet getUser(Connection conn, String username) throws SQLException {
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT id, display_name FROM users WHERE name = ?"
        );
        stmt.setString(1, username);
        return stmt.executeQuery();
    }

    // ✓ Anonymized user record — no sensitive demographics
    static class UserRecord {
        String userId;      // Anonymized hash ID
        String ageBracket;  // "18-24", "25-34", etc. — not exact age
        // No name, email, race, religion, biometric fields
    }

    // ✓ Log action IDs only — never passwords or PII
    public static boolean loginUser(String userId, String passwordHash, String storedHash) {
        if (passwordHash.equals(storedHash)) {
            LOGGER.info("Auth success: userId=" + userId);
            return true;
        }
        LOGGER.warning("Auth failure: userId=" + userId);
        return false;
    }

    // ✓ Password hashing utility
    public static String hashPassword(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(password.getBytes("UTF-8"));
        StringBuilder hex = new StringBuilder();
        for (byte b : hash) hex.append(String.format("%02x", b));
        return hex.toString();
    }

    // ✓ O(n) duplicate detection with HashSet
    public static <T> List<T> findDuplicates(List<T> list) {
        Set<T> seen = new HashSet<>();
        Set<T> duplicates = new LinkedHashSet<>();
        for (T item : list) {
            if (!seen.add(item)) duplicates.add(item);
        }
        return new ArrayList<>(duplicates);
    }

    // ✓ Polling loop with explicit exit condition
    public static void pollServer(int maxRetries) {
        int retries = 0;
        while (retries < maxRetries) {
            LOGGER.info("Poll attempt " + (retries + 1));
            retries++;
            // Break on success condition
            if (retries >= maxRetries) break;
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println(buildMatrix(5));

        String pwHash = hashPassword("user_password");
        loginUser("user-8a3f1c", pwHash, pwHash);

        List<Integer> data = Arrays.asList(1, 2, 3, 2, 4, 1, 5);
        System.out.println("Duplicates: " + findDuplicates(data));

        pollServer(3);
    }
}
