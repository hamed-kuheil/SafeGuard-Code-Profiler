# examples/python/good_example.py
# SafeGuard Demo — Clean, efficient, and ethically sound Python code.

import os
import sqlite3
import hashlib
import logging
from typing import Optional

# ✓ Configure logger — never log sensitive fields
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ✓ Credentials from environment, never hardcoded
API_KEY  = os.environ.get("API_KEY")
DB_URL   = os.environ.get("DATABASE_URL")

if not API_KEY:
    raise EnvironmentError("API_KEY environment variable is required")

# ✓ O(n) duplicate detection using a set
def find_duplicates_fast(data: list) -> list:
    seen = set()
    duplicates = set()
    for item in data:
        if item in seen:
            duplicates.add(item)
        seen.add(item)
    return list(duplicates)

# ✓ File opened with context manager — guaranteed close
def read_file_safe(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

# ✓ O(n) string building with list + join
def build_report_fast(items: list) -> str:
    return "\n".join(str(item) for item in items)

# ✓ Parameterized query — safe from SQL injection
def get_user(conn: sqlite3.Connection, username: str) -> list:
    cursor = conn.cursor()
    cursor.execute("SELECT id, display_name FROM users WHERE name = ?", (username,))
    return cursor.fetchall()

# ✓ No shell=True, no string concatenation in command
def list_directory(dirpath: str) -> list:
    import subprocess
    result = subprocess.run(["ls", dirpath], capture_output=True, text=True, timeout=5)
    return result.stdout.splitlines()

# ✓ Anonymized user model — no sensitive demographics
class UserProfile:
    def __init__(self, user_id: str, age_bracket: str):
        self.user_id     = user_id       # Anonymized hash, not real name
        self.age_bracket = age_bracket   # e.g. "25-34", not exact age
        # No race, gender, religion, biometric fields stored

    def anonymize_id(self, raw_id: str) -> str:
        return hashlib.sha256(raw_id.encode()).hexdigest()[:16]

# ✓ Passwords hashed — never logged or stored in plaintext
def authenticate(username: str, password: str, stored_hash: str) -> bool:
    pw_hash = hashlib.sha256(password.encode()).hexdigest()
    if pw_hash == stored_hash:
        logger.info("Auth success for user_id=%s", username)  # Log ID, not password
        return True
    logger.warning("Auth failure for user_id=%s", username)
    return False

# ✓ Consent-gated biometric collection
def store_biometric_with_consent(user_id: str, biometric_data: bytes,
                                  consent_token: Optional[str]) -> bool:
    if not consent_token:
        logger.error("Biometric storage refused: no consent token for user %s", user_id)
        return False
    # Encrypt before storing (placeholder)
    encrypted = hashlib.sha256(biometric_data).hexdigest()
    logger.info("Biometric stored (encrypted) for user %s", user_id)
    return True

# ✓ Safe deserialization — JSON instead of pickle
def load_model_safe(path: str) -> dict:
    import json
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

if __name__ == "__main__":
    data = [1, 2, 3, 2, 1, 4, 3]
    print(find_duplicates_fast(data))
    print(build_report_fast(data))

    user = UserProfile("user-abc123", "25-34")
    stored_hash = hashlib.sha256(b"test_password").hexdigest()
    authenticate("user-abc123", "test_password", stored_hash)
