# examples/python/bad_example.py
# SafeGuard Demo — Deliberately insecure and inefficient Python code.
# DO NOT replicate these patterns.

import os
import sqlite3
import subprocess
import pickle

# SEC-001: Hardcoded credentials
password = "admin123!"
api_key = "sk-live-AbCdEf1234567890XYZPQR"
token = "Bearer eyJhbGciOiJIUzI1NiJ9.payload.signature"

# ETH-001: Hardcoded PII — email
admin_email = "alice.johnson@corp.com"

# ETH-003: SSN hardcoded
test_ssn = "123-45-6789"

# EFF-001 + EFF-002: Nested loops — O(n^2) or worse
def find_duplicates_slow(data):
    duplicates = []
    for i in range(len(data)):       # O(n^2) — use a set instead
        for j in range(len(data)):
            if i != j and data[i] == data[j]:
                duplicates.append(data[i])
    return duplicates

# EFF-005: File opened without context manager
def read_file_bad(path):
    f = open(path, "r")              # No 'with' block — risk of unclosed handle
    content = f.read()
    # f.close() missing if exception occurs
    return content

# EFF-006: String concatenation in a loop
def build_report_slow(items):
    report = ""
    for item in items:
        report += str(item) + "\n"   # O(n^2) — use list + "".join()
    return report

# SEC-006: SQL injection risk
def get_user(conn, username):
    cursor = conn.cursor()
    query = "SELECT * FROM users WHERE name = '" + username + "'"  # Injection!
    cursor.execute(query)
    return cursor.fetchall()

# SEC-007: Shell injection risk
def run_command(user_input):
    os.system("ls " + user_input)    # Command injection — never concatenate
    subprocess.call("echo " + user_input, shell=True)

# SEC-008: eval() usage
def compute(expression):
    return eval(expression)          # Arbitrary code execution risk!

# ETH-005: Sensitive demographic fields
user_profile = {
    "name":   "Jane Doe",
    "email":  "jane@example.com",
    "race":   "Asian",           # ETH-005: sensitive demographic
    "gender": "Female",          # ETH-005: sensitive demographic
    "religion": "Buddhist",      # ETH-005: sensitive demographic
}

# ETH-007: Logging sensitive data
def authenticate(user, pwd):
    print(f"Authenticating user: {user} with password: {pwd}")  # NEVER log passwords

# ETH-004: Biometric field
def store_biometric(user_id, face_id, fingerprint):
    print(f"Storing biometric for {user_id}: {face_id}")   # No consent check!

# SEC-012: Unsafe pickle deserialization
def load_model(path):
    with open(path, "rb") as f:
        return pickle.load(f)        # Arbitrary code execution on untrusted data

# SEC-010: Developer notes
# TODO: Add input validation here
# FIXME: This crashes with empty list
# HACK: Skipping auth for testing

if __name__ == "__main__":
    data = [1, 2, 3, 2, 1, 4, 3]
    print(find_duplicates_slow(data))
    print(build_report_slow(data))
    print(compute("2 + 2"))   # SEC-008
    authenticate("admin", "secret123")  # ETH-007
