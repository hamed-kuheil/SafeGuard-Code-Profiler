# SafeGuard-Code Profiler

```
  ____         __       ____                        _
 / ___|  __ _ / _| ___ / ___|_   _  __ _ _ __ __| |
 \___ \ / _` | |_ / _ \ |  _| | | |/ _` | '__/ _` |
  ___) | (_| |  _|  __/ |_| | |_| | (_| | | | (_| |
 |____/ \__,_|_|  \___|\____|\__,_|\__,_|_|  \__,_|

  [ Resource Efficiency · Security · AI Ethics ]
```

> **A lightweight static analysis tool for Computer Engineering students** —
> scan C++, Java, and Python for performance bottlenecks, security vulnerabilities,
> and ethical data-handling concerns. No external APIs. No internet required. Pure Python + Regex.

---

## Engineering Philosophy

Modern software exists at the intersection of three responsibilities:

**1. Hardware Awareness → Resource Efficiency**
Every line of code runs on physical silicon. A nested O(n²) loop isn't just
slow — it translates to wasted CPU cycles, excess power draw, and thermal
load. Engineers who understand the hardware beneath their abstractions write
code that respects those constraints. SafeGuard flags patterns that betray
hardware-aware thinking: unclosed file handles (wasting OS resources), memory
allocations without matching frees (heap fragmentation), and algorithmic
inefficiencies that scale poorly on constrained devices.

**2. Security as Correctness**
A buffer overflow isn't just a crash — it's a correctness failure that can
be weaponized. Hardcoded credentials aren't just bad style — they're attack
vectors waiting to be committed to a public repository. SafeGuard treats
security rules as first-class correctness criteria: code that leaks secrets
or allows injection is *wrong code*, not just *risky code*.

**3. Ethical Compliance as Engineering Discipline**
As AI systems are trained on real-world data, the ethical quality of that
data — and the code that collects, stores, and transmits it — becomes an
engineering concern. Storing PII without consent, logging passwords, or
embedding demographic attributes without safeguards isn't just a legal risk
(GDPR, CCPA, COPPA) — it's a design failure. SafeGuard surfaces these
patterns at the code level, where they're cheapest to fix.

**The Scores**
- **Resource Efficiency Score (1–10):** Starts at 10. Deducted per efficiency finding
  weighted by severity. A score below 6 indicates algorithmic or resource-management issues.
- **Ethical Safety Score (1–10):** Starts at 10. Deducted per security and ethics finding.
  A score below 6 indicates serious risks — PII exposure, injection vulnerabilities, or
  unsafe function usage.

---

## Project Structure

```
safeguard/
├── src/
│   ├── main.py          ← CLI entry point (argparse)
│   ├── scanner.py       ← Core scanning engine
│   ├── rules.py         ← All regex-based rule definitions
│   └── formatter.py     ← CLI output + JSON/HTML report generators
│
├── examples/
│   ├── cpp/
│   │   ├── bad_example.cpp    ← Demonstrates 10+ rule violations
│   │   └── good_example.cpp   ← Clean reference implementation
│   ├── java/
│   │   ├── BadExample.java
│   │   └── GoodExample.java
│   └── python/
│       ├── bad_example.py
│       └── good_example.py
│
├── reports/             ← JSON + HTML reports are saved here
├── requirements.txt
└── README.md
```

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

> `colorama` is the only dependency. The tool is fully functional without it
> (falls back to plain text output).

### 2. Scan a single file

```bash
python src/main.py examples/python/bad_example.py
```

### 3. Scan a directory recursively

```bash
python src/main.py examples/ --recursive
```

### 4. Generate full reports

```bash
python src/main.py examples/ --recursive --json --html
```
Reports are saved to `reports/report_<timestamp>.json` and `.html`.

### 5. Verbose mode (shows fix recommendations)

```bash
python src/main.py examples/cpp/bad_example.cpp --verbose
```

### 6. Filter by minimum severity

```bash
python src/main.py examples/ --recursive --min-severity HIGH
```

---

## CLI Reference

```
usage: safeguard [-h] [-r] [-v] [--json] [--html]
                 [--output-dir DIR] [--no-banner]
                 [--min-severity {CRITICAL,HIGH,MEDIUM,LOW,INFO}]
                 target

positional arguments:
  target                File or directory to scan

options:
  -h, --help            Show this help message
  -r, --recursive       Recursively scan directories (default: on)
  -v, --verbose         Show detailed fix recommendations
  --json                Save JSON report
  --html                Save HTML report (dark-theme dashboard)
  --output-dir DIR      Output directory for reports (default: reports/)
  --no-banner           Suppress ASCII art (useful for CI)
  --min-severity LEVEL  Filter findings below this level
```

**Exit Codes:**
- `0` — Scan complete, no CRITICAL findings
- `2` — One or more CRITICAL findings detected (useful for CI/CD gates)

---

## Rule Catalogue

### ⚡ Efficiency Rules

| ID       | Name                          | Severity | Languages         |
|----------|-------------------------------|----------|-------------------|
| EFF-001  | Nested Loop (O(n²) Risk)      | HIGH     | C++, Java, Python |
| EFF-002  | Python Nested For-Loop        | HIGH     | Python            |
| EFF-003  | C++ new Without delete        | HIGH     | C++               |
| EFF-004  | Unclosed File Stream (C++)    | MEDIUM   | C++               |
| EFF-005  | Unclosed File (Python)        | MEDIUM   | Python            |
| EFF-006  | String Concat in Loop         | MEDIUM   | Java, Python      |
| EFF-007  | Java String += in Loop        | MEDIUM   | Java              |
| EFF-008  | Infinite Loop Risk            | MEDIUM   | C++, Java         |
| EFF-009  | Python While True             | LOW      | Python            |
| EFF-010  | Redundant Recomputation       | LOW      | All               |

### 🔒 Security Rules

| ID       | Name                          | Severity | Languages         |
|----------|-------------------------------|----------|-------------------|
| SEC-001  | Hardcoded Password            | CRITICAL | All               |
| SEC-002  | Hardcoded API Key / Token     | CRITICAL | All               |
| SEC-003  | Unsafe C Function: gets()     | CRITICAL | C++               |
| SEC-004  | Unsafe C Function: strcpy()   | HIGH     | C++               |
| SEC-005  | Unsafe C Function: sprintf()  | HIGH     | C++               |
| SEC-006  | SQL Injection Risk            | CRITICAL | Python, Java      |
| SEC-007  | Shell Injection Risk          | CRITICAL | Python            |
| SEC-008  | Eval / Exec Usage             | HIGH     | Python            |
| SEC-009  | Hardcoded IP Address          | LOW      | All               |
| SEC-010  | Debug / TODO Left In Code     | LOW      | All               |
| SEC-011  | Java Reflection Usage         | MEDIUM   | Java              |
| SEC-012  | Pickle Deserialization        | HIGH     | Python            |

### 🧭 Ethics / PII Rules

| ID       | Name                          | Severity | Languages         |
|----------|-------------------------------|----------|-------------------|
| ETH-001  | PII — Email Address           | HIGH     | All               |
| ETH-002  | PII — Phone Number            | HIGH     | All               |
| ETH-003  | PII — SSN / ID Number         | CRITICAL | All               |
| ETH-004  | Biometric Field               | HIGH     | All               |
| ETH-005  | Race/Gender/Religion Attr     | HIGH     | All               |
| ETH-006  | Missing Consent Reference     | MEDIUM   | All               |
| ETH-007  | Logging Sensitive Data        | CRITICAL | All               |
| ETH-008  | Unencrypted Sensitive Storage | HIGH     | All               |
| ETH-009  | Third-Party Data Sharing      | MEDIUM   | All               |
| ETH-010  | Age / Minor Targeting         | HIGH     | All               |

---

## Output Formats

### CLI (colorized)
Color-coded by severity: 🔴 CRITICAL → 🟡 HIGH → 🔵 MEDIUM → ⚪ LOW.
Includes score bars and a global aggregate summary.

### JSON (`--json`)
Machine-readable. Suitable for integration into CI pipelines, dashboards,
or feeding into other tooling.

```json
{
  "tool": "SafeGuard-Code Profiler",
  "version": "1.0.0",
  "timestamp": "2025-01-15T14:32:07",
  "results": [ ... ],
  "aggregate": {
    "total_files": 6,
    "total_findings": 23,
    "critical": 5,
    "high": 9,
    "avg_efficiency": 6.2,
    "avg_ethics": 4.1
  }
}
```

### HTML (`--html`)
Dark-theme dashboard with:
- Severity breakdown counters
- Per-file score bars (green/yellow/red)
- Sortable findings table with code snippets

---

## CI/CD Integration

```yaml
# .github/workflows/safeguard.yml
- name: SafeGuard Scan
  run: |
    pip install colorama
    python src/main.py src/ --recursive --no-banner --min-severity HIGH
    # Exits with code 2 if CRITICAL findings exist — fails the build
```

---

## Extending SafeGuard

Add a new rule to `src/rules.py` following this template:

```python
{
    "id":        "SEC-013",
    "name":      "My New Rule",
    "pattern":   r"some_regex_pattern",
    "severity":  HIGH,
    "category":  "security",       # "efficiency" | "security" | "ethics"
    "message":   "Human-readable explanation and fix advice.",
    "languages": ["python", "java"],
}
```

The scanner picks it up automatically — no other files need changing.

---

## Supported Languages

| Language | Extensions           |
|----------|----------------------|
| Python   | `.py`                |
| Java     | `.java`              |
| C/C++    | `.cpp` `.cxx` `.cc` `.c` `.h` `.hpp` |

---

## Limitations

- **Regex-based:** Inter-procedural analysis (e.g., tracking a variable across
  function calls) is out of scope. For deeper analysis, pair with tools like
  Semgrep, Bandit (Python), or SonarQube.
- **False positives:** Pattern matching may flag commented-out code or string
  literals in tests. Use `--min-severity` to reduce noise.
- **No type inference:** Dynamic language features (e.g., Python duck-typing)
  may cause rules to miss or over-fire.

---

## License

MIT License — Free for educational and personal use.

---

*SafeGuard-Code Profiler — Bridging hardware awareness with software ethics.*
